# -*- coding: utf-8 -*-
# @Author   : Administrator
# @DateTime : 2020/6/21 17:18
# @FileName : main.py
# @SoftWare : PyCharm

"""
命令行： python main.py -e 2 -f Tablet -o 1
"""

import sys

