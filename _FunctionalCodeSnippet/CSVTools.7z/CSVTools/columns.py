# -*- coding: utf-8 -*-
# @Author   : Administrator
# @DateTime : 2020/6/21 14:14
# @FileName : columns.py
# @SoftWare : PyCharm

from attrdict import AttrDict

LABELS = ['L0', 'L1', 'L2', 'L3']

L0_LIST = [
    'Mobile Phone',
    'Tablet',
    'Watch',
    'Printer',
    'VoIP Device',
    'Router',
    'Access Point',
    'Set-top box',
    'IP Camera',
    'Firewall',
    'Aud_Img_Vid_Equ',
    'Switch',
    'Storage Device'
]


FEATURES_LIST = [
    'DHCP_Option 55',
    'DHCP_Option 60',
    'DHCP_HostName',
    'LLD[_Model name',
    'LLDP_Manufacture Name',
    'LLDP_System Description',
    'LLDP_System Name',
    'MDNS_SRV Service',
    'MDNS_Model Name',
    'HTTP_UserAgent',
    'CDP_Platform']


# TODO: 将下面的key全部改成 规则提取 对应的输入文件的文件名, generate_L0_file中使用
MOBILE_PHONE_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60', 'HTTP_UserAgent']
Tablet = ['DHCP_Option 55', 'DHCP_Option 60', 'HTTP_UserAgent']
WATCH_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60', 'HTTP_UserAgent']

ROUTER_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60']
SET_TOP_BOX_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60']
FIREWALL_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60']
AIV_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60']
SWITCH_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60']
STORAGE_DEVICE_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60']

AP_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60', 'LLDP_System Description']

PRINTER_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60', 'DHCP_HostName', 'MDNS_SRV Service']
IP_CAMERA_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60', 'DHCP_HostName', 'MDNS_SRV Service']

VOIP_DEVICE_FEATURES = ['DHCP_Option 55', 'DHCP_Option 60', 'DHCP_HostName',
                        'LLD[_Model name', 'LLDP_Manufacture Name', 'LLDP_System Description', 'LLDP_System Name',
                        'MDNS_SRV Service', 'MDNS_Model Name',
                        'HTTP_UserAgent', 'CDP_Platform']

branch = AttrDict()
# TODO: 将下面的key全部改成 规则提取 对应的输入文件的文件名
branch.MOBILE_PHONE_FEATURES = MOBILE_PHONE_FEATURES
branch.Tablet = Tablet
branch.WATCH_FEATURES = WATCH_FEATURES
branch.ROUTER_FEATURES = ROUTER_FEATURES
branch.SET_TOP_BOX_FEATURES = SET_TOP_BOX_FEATURES
branch.FIREWALL_FEATURES = FIREWALL_FEATURES
branch.AIV_FEATURES = AIV_FEATURES
branch.SWITCH_FEATURES = SWITCH_FEATURES
branch.STORAGE_DEVICE_FEATURES = STORAGE_DEVICE_FEATURES
branch.AP_FEATURES = AP_FEATURES
branch.PRINTER_FEATURES = PRINTER_FEATURES
branch.IP_CAMERA_FEATURES = IP_CAMERA_FEATURES
branch.VOIP_DEVICE_FEATURES = VOIP_DEVICE_FEATURES
