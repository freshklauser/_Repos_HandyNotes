# -*- coding: utf-8 -*-
# @Author   : Administrator
# @DateTime : 2020/6/21 21:36
# @FileName : full_post_process.py
# @SoftWare : PyCharm


def full_post_proc(rule_abs_path):
    # print(rule_abs_path)
    print('full_post_process')
