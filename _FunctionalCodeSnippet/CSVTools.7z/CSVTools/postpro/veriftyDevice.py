# -*- coding: utf-8 -*-
# @Author   : Administrator
# @DateTime : 2020/6/21 21:31
# @FileName : veriftyDevice.py
# @SoftWare : PyCharm


def verify_device(rule_abs_path, dev_tree_abs_path):
    # print(rule_abs_path)
    # print(dev_tree_abs_path)
    print('verify device')