# -*- coding: utf-8 -*-
# @Author   : Administrator
# @DateTime : 2020/6/21 21:34
# @FileName : postpro.py
# @SoftWare : PyCharm


def post_process(rule_abs_path, dev_tree_abs_path):
    # print(rule_abs_path)
    # print(dev_tree_abs_path)
    print('post process')
