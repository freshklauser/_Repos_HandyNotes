# -*- coding: utf-8 -*-
# @Author   : Administrator
# @DateTime : 2020/6/21 21:29
# @FileName : addOSRule.py
# @SoftWare : PyCharm


def add_os_rule(rule_abs_path, dev_tree_abs_path):
    # print(rule_abs_path)
    # print(dev_tree_abs_path)
    print('add os rule')

